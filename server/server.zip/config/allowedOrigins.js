const allowedOrigins = [
    'http://127.0.0.1:3000',
    'http://localhost:3500',
    'http://localhost:3001',
    'http://localhost:3000',
    'http://localhost:4002',
    'http://127.0.0.1:3001',
    'http://127.0.0.1:4002',
    'http://iu4juaymdk.preview.infomaniak.website',

];

module.exports = allowedOrigins;